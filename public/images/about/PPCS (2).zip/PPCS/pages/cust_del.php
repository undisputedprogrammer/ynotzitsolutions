<?php
include '../includes/connection.php';

// Check if the 'id' parameter is passed in the URL
if (isset($_GET['id'])) {
    $customerId = $_GET['id'];

    // Delete the customer from the database
    $query0 = "DELETE FROM transaction WHERE CUST_ID = $customerId";
    mysqli_query($db, $query0) or die(mysqli_error($db));
    $query = "DELETE FROM customer WHERE CUST_ID = $customerId";
    $result = mysqli_query($db, $query) or die(mysqli_error($db));

    // Check if the delete query was successful
    if ($result) {
        // Redirect to the customers page
        header("Location: customer.php");
        exit();
    } else {
        echo "Failed to delete the customer. Please try again.";
    }
} else {
    echo "Customer ID not specified. Please provide a valid ID.";
}
?>