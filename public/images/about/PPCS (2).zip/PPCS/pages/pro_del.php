<?php
include '../includes/connection.php';

// Check if the 'id' parameter is passed in the URL
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Delete the product from the database
    $query = "DELETE FROM product WHERE PRODUCT_CODE = $productId";
    $result = mysqli_query($db, $query) or die(mysqli_error($db));

    // Check if the delete query was successful
    if ($result) {
        // Redirect to the products page
        header("Location: product.php");
        exit();
    } else {
        echo "Failed to delete the product. Please try again.";
    }
} else {
    echo "Product ID not specified. Please provide a valid ID.";
}
?>







